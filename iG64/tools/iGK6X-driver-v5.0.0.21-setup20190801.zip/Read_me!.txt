Users who installed the old version (versions before 20190801), please manually execute the following after installed the new driver software:

0)Run the newly installed driver tool software.

1)Please backup your DIY light effects manually. This way to backup your DIY light:
  Please click the top menu "DIY Light", then click the DIY light name in the column, and then click the small "Emport" icon (a "Down"arrow icon which is at the first position from bottom), a file dialog box pops up, then save the DIY light to a folder, one by one like this to save all your DIY light effects.

2)Exit the driver tool software.

3) Delete all files in the folder:
 (XP OS) C:\Documents and Settings\Administrator\Application Data\GK6XPlus-CMS\Account\0\LE
or
 (Win 7 OS)C:\Users\Administrator\AppData\Roaming\GK6XPlus-CMS\Account\0\LE
(above "Administrator" is computer's username.)

4) Copy all the files in the folder:
C:\Program Files\GK6XPlus Driver\CMSEngine\driver\res\data\le
(above "C:\Program Files\" is the install path.)

to the folder:
(XP OS) C:\Documents and Settings\Administrator\Application Data\GK6XPlus-CMS\Account\0\LE
or
 (Win 7 OS)C:\Users\Administrator\AppData\Roaming\GK6XPlus-CMS\Account\0\LE
(above "Administrator" is computer's username.)

5) Rename the file "lelist_en.json" to be "lelist.json"

6) Run the driver tool software, and import your backup DIY light effects. this step is like above step 1, click the small "Import" icon (a "UP"arrow icon which is at the 2nd position from bottom).
  